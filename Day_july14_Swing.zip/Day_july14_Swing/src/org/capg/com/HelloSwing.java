package org.capg.com;

import java.awt.Color;
import java.awt.Container;

import javax.swing.*;

public class HelloSwing {

	public static void main(String[] args) {
		JFrame frame=new JFrame();
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(700, 500);
		frame.setLocation(100, 50);
        frame.setBounds(100,100,1000,500);
        frame.setTitle("Hello Swing");
        ImageIcon icon=new ImageIcon("Give image path here");
        frame.setIconImage(icon.getImage());
        Container c=frame.getContentPane();
        c.setBackground(Color.LIGHT_GRAY);
        //frame.setResizable(true);
        frame.setResizable(false);
	}

}
