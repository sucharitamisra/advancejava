package org.capg.com;

public class NewLabel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
