package com.flp.pms.view;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForDB;

 
public class DeleteProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 IProductDao db=new ProductDaoImplForDB();
		 String pid=request.getParameter("productId");
		 int prodId=Integer.parseInt(pid);
		 db.removeProduct(prodId);
	}

	 

}
