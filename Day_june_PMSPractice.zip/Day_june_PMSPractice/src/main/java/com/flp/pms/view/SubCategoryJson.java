package com.flp.pms.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImplForDB;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.SubCategory;
import com.google.gson.Gson;
 
@SuppressWarnings("unused")
public class SubCategoryJson extends HttpServlet {
	private static final long serialVersionUID = 1L;

	 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("application/json");
		 PrintWriter out=response.getWriter();
		
		IProductDao db=new ProductDaoImplForDB();
		 List<SubCategory> subcategories=db.getAllSubCategory();
		 Gson myJson=new Gson();
		 String subcategory=myJson.toJson(subcategories);
		 out.println(subcategory);
	}

}
