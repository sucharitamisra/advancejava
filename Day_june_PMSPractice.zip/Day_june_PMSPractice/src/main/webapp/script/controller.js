app.controller("myController",function($scope,$http)
		{
	
		$http.get( 'http://localhost:8080/Day_june_PMSPractice/CategoryJson').success(function(response)
				{
			 
			$scope.cats = response;
				});
		$http.get( 'http://localhost:8080/Day_june_PMSPractice/CategoryJson').error(function(errormsg) {
					$scope.cats = errormsg;
				});


		$http.get('http://localhost:8080/Day_june_PMSPractice/SubCategoryJson').success(function(response)
				{
			$scope.subcategory = response;
				})
				$http.get('http://localhost:8080/Day_june_PMSPractice/SubCategoryJson').error(function(errormsg) {
					$scope.subcategory = errormsg;
				});

	 
		
		$http.get('http://localhost:8080/Day_june_PMSPractice/SupplierJson').success(function(response)
				{
			$scope.supplier = response;
				})
				$http.get('http://localhost:8080/Day_june_PMSPractice/SupplierJson').error(function(errormsg) {
					$scope.supplier = errormsg;
				});


		$http.get('http://localhost:8080/Day_june_PMSPractice/DiscountJson').success(function(response)
				{
			$scope.discount = response;
				})
				$http.get('http://localhost:8080/Day_june_PMSPractice/DiscountJson').error(function(errormsg) {
					$scope.discount = errormsg;
				});
		});