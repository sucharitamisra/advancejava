package org.capg.demo;

import java.util.*;
public class Hancock {
// insert code here Linea 5
	 public void addStrings(List<String> list){ 
list.add("foo");
}
}

